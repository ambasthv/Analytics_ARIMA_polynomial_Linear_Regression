
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import os
import seaborn as sns

from matplotlib import pyplot as plt
get_ipython().magic('matplotlib inline')
from sklearn.decomposition import PCA 
from sklearn.cluster import KMeans
from sklearn import preprocessing
from sklearn.metrics import silhouette_samples, silhouette_score
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.metrics import roc_auc_score,roc_curve,classification_report,confusion_matrix, accuracy_score
import statsmodels.formula.api as SM
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV


# In[2]:


os.chdir("C:\\Users\\brashmir\\Desktop\\Consumer cards - data analysis")
data = pd.read_excel("Analysis tools.xlsx")
data.head()


# In[3]:


data.shape


# In[4]:


data.dtypes


# In[5]:


data.describe()


# ## Imputing Null values

# In[6]:


data.isnull().sum()


# In[7]:


df= data.drop(['INCOMEVERIFIEDFLAG','Age_Band','Activation'], axis = 1)


# In[8]:


df.info()


# In[9]:


df = df.fillna(0)


# In[10]:


check=(df == 0).sum()
check


# In[11]:


df.isnull().sum()


# In[12]:


df.nunique()


# In[13]:


dups=df.duplicated()
print('Number of duplicate rows = %d' %(dups.sum()))
df[dups]


# ## Exploratory data Analysis

# In[14]:


df['Final_Decision'].value_counts(normalize = True)


# In[15]:


df["Final_Decision"].value_counts().sort_index().plot.bar()
df.Final_Decision.value_counts()


# In[16]:


sns.distplot(df['AGE'])


# In[17]:


pd.value_counts(df['customer_type']).plot(kind = "pie", autopct='%1.1f%%')
plt.show()


# In[18]:


plt.figure(figsize=(20,20))
ax = sns.barplot(x= 'total_gross_income', y=  'Product' ,hue= df['Final_Decision'] , data=df)


# In[19]:


Ch = df.groupby(['Final_Decision','Channel'])
print(Ch.size())

fig,ax = plt.subplots(figsize=(7,7))

df.groupby(['Final_Decision','Channel']).count()['total_gross_income'].unstack().plot(ax=ax, kind='bar' )


# In[20]:


plt.figure(figsize=(10,5))
ax = sns.barplot(x='Age_Band' , y='total_gross_income' , data=data)


# In[21]:


plt.figure(figsize=(12,10))
sns.countplot(y=(df['Industry']),hue= df['PERMANENTRESIDENT'], palette='PuRd_r');


# In[22]:


sns.pairplot(df)
plt.show()


# g = sns.pairplot(df, kind='reg', plot_kws={'line_kws':{'color':'red'}, 'scatter_kws': {'alpha': 0.1}})
# g.fig.set_size_inches(15,15)

# In[23]:


plt.figure(figsize=(10,5))
ax = sns.barplot(x='income_band' , y='total_gross_income' , data=df);
ax


# In[24]:


from scipy.stats import pearsonr
corr, _ = pearsonr(df.hem, df.UMI)
print('pearson correlation: %.3f' % corr)


# In[25]:


df.corr()


# In[26]:


cor=df.corr()
plt.figure(figsize=(10, 8))
sns.heatmap(cor,annot = True, vmin= -1, vmax=1, center=0);


# In[27]:


options = ['Approve']
df['LIMITLOANREQUESTED']= df['LIMITLOANREQUESTED'].astype(int)
df['LIMITALLOCATED']=df['LIMITALLOCATED'].astype(int)


# In[28]:


approve_df = df[df['Final_Decision'].isin(options)]
print(approve_df[['LIMITLOANREQUESTED','LIMITALLOCATED','Final_Decision']])


# In[29]:


plt.figure(figsize=(10,10))
ax = sns.distplot(approve_df.LIMITLOANREQUESTED, kde=True );


# In[30]:


approve_df.LIMITALLOCATED.hist(figsize=(8,8), color= 'g', edgecolor ='red');
print('Limit allocated which got approved =', approve_df.LIMITALLOCATED.count())


# In[31]:


options2 = ['Decline']
decline_df = df[df['Final_Decision'].isin(options2)]


# In[32]:


plt.figure(figsize=(10,10))
ax = sns.distplot(decline_df.LIMITLOANREQUESTED, kde=True );


# In[33]:


decline_df.LIMITALLOCATED.hist(figsize=(8,8),color= 'r', edgecolor ='blue');
print('Limit allocated which got declined =', decline_df.LIMITALLOCATED.count())


# In[34]:


plt.figure(figsize=(15,5))
sns.countplot(x = "EMPLOYCURRSTATUS", data =df, order = df['EMPLOYCURRSTATUS'].value_counts().index, palette="RdYlBu", hue ='Final_Decision')
plt.title('Employment status of the customer')
plt.show();


# In[35]:


fig, axes = plt.subplots(nrows=2,ncols=5)
fig.set_size_inches(20, 20)
a = sns.boxplot(data=df[['AGE']] ,
                orient = "v" , ax=axes[0][0])

b = sns.boxplot(data=df[['Interest Rate - PA']] ,
                orient = "v" , ax=axes[0][1])

c = sns.boxplot(data=df[['drawn']] ,
                orient = "v" , ax=axes[0][2])

d = sns.boxplot(data=df[['hem']]
                , orient = "v" , ax=axes[0][3])

e = sns.boxplot(data=df[['LIMITALLOCATED']]
                , orient = "v" , ax=axes[0][4])

f = sns.boxplot(data=df[['LIMITLOANREQUESTED']]
                , orient = "v" , ax=axes[1][0])

g = sns.boxplot(data=df[['total_gross_income']]
                , orient = "v" , ax=axes[1][1])

h = sns.boxplot(data=df[['UMI']]
                , orient = "v" , ax=axes[1][2])

i = sns.boxplot(data=df[['Time to decision']]
                , orient = "v" , ax=axes[1][3])


# In[36]:


decline_df['Description'].value_counts()


# In[37]:


approve_df['Description'].value_counts()


# In[38]:


decline_df['reason'].value_counts().head(15)


# In[39]:


approve_df['reason'].value_counts().head(15)


# In[40]:


print(df['State'].value_counts(),'\n')
sns.boxplot(x='State', y="LIMITALLOCATED",  data=df,palette='summer')


# In[41]:


plt.figure(figsize=(8,5))

sns.boxplot(df['Final_Decision'], df['Time to decision']);


# In[42]:


index_names = df[(df['Final_Decision'] == 'Pending')].index
index_names2 = df[(df['Final_Decision'] == 'Expired')].index

df.drop(index_names, inplace = True)


# In[43]:


df.drop(index_names2, inplace = True)
## Dropped Pending and expired


# In[44]:


plt.figure(figsize=(8,5))

sns.boxplot(df['Final_Decision'], df['Time to decision']);


# In[45]:


credit_df = df[['AGE','App Number','ApptIncomeVerifiedFlag','BT_flag','customer_type','Description','EMPLOYCURRSTATUS','Final_Decision','LIMITLOANREQUESTED','PERMANENTRESIDENT','Policy_Decision_fs','Product','hem', 'reason','total_gross_income', 'UMI', 'Time to decision']]


# In[46]:


credit_df.head(10)


# In[47]:


print('number of rows', credit_df.shape[0], ',number of columns', credit_df.shape[1])


# In[48]:


credit_df.to_excel('credit_df.xlsx', index=False)


# In[49]:


credit_df = pd.read_excel("credit_df.xlsx")


# In[50]:


credit_df.info()


# In[51]:


cor=credit_df.corr()
plt.figure(figsize=(10, 8))
sns.heatmap(cor,annot = True, vmin= -1, vmax=1, center=0 , cmap = "Oranges" );


# In[52]:


##
grouped = df.groupby(['Final_Decision','Triex_used'])
grouped.size()


# In[53]:


b=df.groupby(['App Type','Product'])
b.size()


# In[54]:


a = df.groupby(['Final_Decision','ApptIncomeVerifiedFlag'])
a.size()


# In[55]:


fig,ax = plt.subplots(figsize=(7,7))

credit_df.groupby(['Final_Decision','ApptIncomeVerifiedFlag']).count()['total_gross_income'].unstack().plot(ax=ax, kind='bar' )


# In[56]:


grouped = credit_df.groupby(['Final_Decision','PERMANENTRESIDENT'])
print(grouped.size())


# In[57]:


fig,ax = plt.subplots(figsize=(7,7))

credit_df.groupby(['Final_Decision','PERMANENTRESIDENT']).count()['total_gross_income'].unstack(level=0).plot(ax=ax, kind='bar')


# In[58]:


sns.barplot(x='Channel', y= 'UMI', data=df, hue='Final_Decision')
df['Channel'].value_counts()


# In[59]:


df.groupby(['Final_Decision','Channel']).count()['Policy_Decision_fs'].unstack(level=0).plot(ax=ax, kind = "bar", stacked= True);


# In[60]:


## sns.swarmplot(x='Final_Decision', y= 'UMI', data=df, hue='Final_Decision', size = 20)


# In[61]:


df['Product'].value_counts()


# In[62]:


grouped1 = credit_df.groupby(['Policy_Decision_fs','Final_Decision'])
print(grouped1.size())


# In[63]:


fig,ax = plt.subplots(figsize=(7,7))

credit_df.groupby(['Final_Decision','customer_type']).count()['Policy_Decision_fs'].unstack(level=0).plot(ax=ax, kind = "bar", stacked= True) 


# In[64]:


grouped1 = credit_df.groupby(['Policy_Decision_fs','Final_Decision'])
print(grouped1.size())


# In[65]:


credit_df1=credit_df.copy()


# In[66]:


grouped = credit_df.groupby(['Final_Decision','EMPLOYCURRSTATUS'])
print(grouped.size())


# In[67]:


for feature in credit_df:
    if credit_df[feature].dtype == 'object':
        print('feature:', feature)
        print(pd.Categorical(credit_df[feature].unique()))
        print(pd.Categorical(credit_df[feature].unique()).codes)
        credit_df[feature]=pd.Categorical(credit_df[feature]).codes


# In[68]:


credit_df.head()


# In[69]:


credit_df.Description.replace([24,51,37,3,49,53,30,26,52,25,10, 31,50,55,18,1,39,58,40,36,57,56,32,54,27,4,29,0,6,42,16,2,14,17,8,22,23,9,34,20,46,44,43,19,33,45,7,11,12,35,21,13,48,5,15,38,41,47,28],[1,1,1,1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,5,5,5,5,5,5,6,6,6,6,7,7,7,7,8,8,8,8],inplace=True)
credit_df.head()


# In[70]:


credit_df.boxplot(figsize=(20,3))
plt.xticks(rotation=90)
plt.show()


# In[71]:


#Outlier treatment 
def remove_outlier(col):
    sorted(col)
    Q1,Q3=col.quantile([0.25,0.75])
    IQR=Q3-Q1
    lower_range= Q1-(1.5 * IQR)
    upper_range= Q3+(1.5 * IQR)
    return lower_range, upper_range


# In[72]:


lrc,urc=remove_outlier(credit_df['AGE'])
credit_df['AGE']=np.where(credit_df['AGE']>urc,urc,credit_df['AGE'])
credit_df['AGE']=np.where(credit_df['AGE']<lrc,lrc,credit_df['AGE'])


lrr,urr=remove_outlier(credit_df['LIMITLOANREQUESTED'])
credit_df['LIMITLOANREQUESTED']=np.where(credit_df['LIMITLOANREQUESTED']>urr,urr,credit_df['LIMITLOANREQUESTED'])
credit_df['LIMITLOANREQUESTED']=np.where(credit_df['LIMITLOANREQUESTED']<lrr,lrr,credit_df['LIMITLOANREQUESTED'])


lrt,urt=remove_outlier(credit_df['total_gross_income'])
credit_df['total_gross_income']=np.where(credit_df['total_gross_income']>urt,urt,credit_df['total_gross_income'])
credit_df['total_gross_income']=np.where(credit_df['total_gross_income']<lrt,lrt,credit_df['total_gross_income'])

lrt,urt=remove_outlier(credit_df['total_gross_income'])
credit_df['total_gross_income']=np.where(credit_df['total_gross_income']>urt,urt,credit_df['total_gross_income'])
credit_df['total_gross_income']=np.where(credit_df['total_gross_income']<lrt,lrt,credit_df['total_gross_income'])

lru,uru=remove_outlier(credit_df['UMI'])
credit_df['UMI']=np.where(credit_df['UMI']>uru,uru,credit_df['UMI'])
credit_df['UMI']=np.where(credit_df['UMI']<lru,lru,credit_df['UMI'])

lrh,urh=remove_outlier(credit_df['hem'])
credit_df['hem']=np.where(credit_df['hem']>urh,urh,credit_df['UMI'])
credit_df['hem']=np.where(credit_df['hem']<lrh,lrh,credit_df['UMI'])

lrz,urz=remove_outlier(credit_df['Time to decision'])
credit_df['Time to decision']=np.where(credit_df['Time to decision']>urz,urz,credit_df['Time to decision'])
credit_df['Time to decision']=np.where(credit_df['Time to decision']<lrz,lrz,credit_df['Time to decision'])


# In[73]:


credit_df.boxplot(figsize=(20,3))
plt.xticks(rotation=90)
plt.show()


# In[74]:


X=credit_df.drop(["Final_Decision","App Number","total_gross_income", "Time to decision"], axis =1)
y=credit_df.pop("Final_Decision")


# In[75]:


from scipy.stats import zscore

df_new=X.apply(zscore)
df_new.head()


# In[76]:


#PCA
#step 1 - create covariance matrix

cov_matrix =np.cov(df_new.T)
print('Covariance matrix \n%s', cov_matrix)


# In[77]:


df_corr= df_new
df_corr.corr()


# In[78]:


cor=df_new.corr()
plt.figure(figsize=(10, 8))
sns.heatmap(cor,annot = True, vmin= -1, vmax=1, center=0);


# In[79]:


#step 2- Get eigen values and eigen vector
eig_vals, eig_vec =np.linalg.eig(cov_matrix)
print('\n Eigen Values\n %s', eig_vals)
print('\n')
print('Eigen Vectors \n %s', eig_vec)


# In[80]:


tot = sum(eig_vals)
var_exp = [(i/tot)* 100 for i in sorted(eig_vals, reverse=True)]
cum_var_exp=np.cumsum(var_exp)
print("cumulative Variance Explained", cum_var_exp)


# In[81]:


plt.figure(figsize = (7,5))
plt.bar(range(1, eig_vals.size + 1), var_exp, alpha = 0.5, align = 'center', label ='Individual explained variance')
plt.step(range(1, eig_vals.size + 1), cum_var_exp, where='mid', Label = " cumulative variance")
plt.ylabel('Explained Variance Ratio', fontsize=15)
plt.xlabel('Principal components', fontsize=15)
plt.title('EVR', fontsize=15)
plt.legend(loc = 'best')
plt.grid()
plt.show()


# In[82]:


# dimentionality reduction 17-8
pca =PCA(n_components= 8)
data_reduced = pca.fit_transform(df_new)
data_reduced.transpose()


# In[83]:


plt.scatter(data_reduced[:,0], data_reduced[:,1], c=y)
plt.xlabel('PC1')
plt.ylabel('PC2')
plt.show


# In[84]:


pca.components_


# In[85]:


pca.explained_variance_ratio_


# In[86]:


principalDf = pd.DataFrame(data = data_reduced
             , columns = ['PC1', 'PC2', 'PC3', 'PC4', 'PC5', 'PC6','PC7','PC8'])
finalDf = pd.concat([principalDf, y], axis = 1)
finalDf.head()


# In[87]:


df_comp = pd.DataFrame(pca.components_, columns = list(df_new))
df_comp.head()


# In[88]:


plt.figure(figsize=(10, 8))
sns.heatmap(df_comp,annot = True, vmin= -1, vmax=1, center=0);


# In[89]:


k_means = KMeans(n_clusters = 8)
k_means.fit(df_new)


# In[90]:


wss=[]

for i in range(1,11):
    KM=KMeans(n_clusters=i)
    KM.fit(df_new)
    wss.append(KM.inertia_)


# In[91]:


wss


# In[92]:


plt.plot(range(1,11),wss)


# In[93]:


k_means = KMeans(n_clusters = 5, random_state=1)
k_means.fit(df_new)
labels= k_means.labels_
print(labels)


# In[94]:


#silhouette_score(df_new, labels, random_state=None)


# In[95]:


df["labels"]=labels
df.head()


# In[96]:


X=df_new
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30 , random_state=1)


# In[97]:


X.columns


# In[98]:


X.head()


# In[99]:


print('X_train',X_train.shape)
print('X_test',X_test.shape)
print('train_labels',y_train.shape)
print('test_labels',y_test.shape)


# In[100]:


model = LogisticRegression(solver='newton-cg',max_iter=20000,penalty='l2',verbose=True,n_jobs=1)
model.fit(X_train, y_train)


# In[101]:


ytrain_predict = model.predict(X_train)
ytest_predict = model.predict(X_test)


# In[102]:


model_score = model.score(X_test, y_test)
print('Accuracy Score is ',model_score)


# In[103]:


model_score = model.score(X_train, y_train)
print('Accuracy Score is ',model_score)


# In[104]:


f,a =  plt.subplots(1,2,sharex=True,sharey=True,squeeze=False)

plot_0 = sns.heatmap((metrics.confusion_matrix(y_train,ytrain_predict)),annot=True,fmt='.5g',cmap='Greys',ax=a[0][0]);
a[0][0].set_title('Training Data')

plot_1 = sns.heatmap((metrics.confusion_matrix(y_test,ytest_predict)),annot=True,fmt='.5g',cmap='BuPu', ax=a[0][1]);
a[0][1].set_title('Test Data');


# In[105]:


print(classification_report(y_train, ytrain_predict))


# In[106]:


print(classification_report(y_test, ytest_predict))


# In[107]:


def run_LR(X_train, X_test, y_train, y_test):
    LR = LogisticRegression(solver='newton-cg',max_iter=20000,penalty='l2',verbose=True,n_jobs=1)
    LR.fit(X_train,y_train)
    y_pred=LR.predict(X_test)
    print('Accuracy: ', accuracy_score(y_test, y_pred))


# In[108]:


from sklearn.feature_selection import RFE
model1 = LogisticRegression()
#Initializing RFE model
selector = RFE(model1, n_features_to_select=13, step=1)
#Transforming data using RFE
selector = selector.fit(X_train,y_train)  
#Fitting the data to model
selector.n_features_
print(selector.support_)
print(selector.ranking_)


# In[109]:


#LR
df1 = pd.DataFrame({'Feature': X_train.columns, 'Rank': selector.ranking_})
df1[df1['Rank']== 1]


# In[110]:


fpr = {}
tpr = {}
thresh ={}
n_class = 3
pred = model.predict(X_train)
pred_prob = model.predict_proba(X_train)


for i in range(n_class):    
    fpr[i], tpr[i], thresh[i] = roc_curve(y_train, pred_prob[:,i], pos_label=i)
    
# plotting    
plt.plot(fpr[0], tpr[0], linestyle='--',color='orange', label='Class 0 vs Rest')
plt.plot(fpr[1], tpr[1], linestyle='--',color='green', label='Class 1 vs Rest')
plt.plot(fpr[2], tpr[2], linestyle='--',color='blue', label='Class 2 vs Rest')
plt.title('Multiclass ROC curve')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive rate')
plt.legend(loc='best')
plt.savefig('Multiclass ROC',dpi=300); 


# In[111]:


fpr = {}
tpr = {}
thresh ={}
n_class = 3
pred = model.predict(X_test)
pred_prob = model.predict_proba(X_test)


for i in range(n_class):    
    fpr[i], tpr[i], thresh[i] = roc_curve(y_test, pred_prob[:,i], pos_label=i)
    
# plotting    
plt.plot(fpr[0], tpr[0], linestyle='--',color='orange', label='Class 0 vs Rest')
plt.plot(fpr[1], tpr[1], linestyle='--',color='green', label='Class 1 vs Rest')
plt.plot(fpr[2], tpr[2], linestyle='--',color='blue', label='Class 2 vs Rest')
plt.title('Multiclass ROC curve')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive rate')
plt.legend(loc='best')
plt.savefig('Multiclass ROC',dpi=300);  


# In[112]:


LR = LogisticRegression(solver='newton-cg',max_iter=20000,penalty='l2',verbose=True,n_jobs=1)
LR.fit(X_train, y_train)


# In[113]:


ytrain_predict = LR.predict(X_train)
ytest_predict = LR.predict(X_test)


# In[114]:


model_score = LR.score(X_test, y_test)
print('Accuracy Score is ',model_score)


# In[115]:


model_score = LR.score(X_train, y_train)
print('Accuracy Score is ',model_score)


# In[116]:


f,a =  plt.subplots(1,2,sharex=True,sharey=True,squeeze=False)

plot_0 = sns.heatmap((metrics.confusion_matrix(y_train,ytrain_predict)),annot=True,fmt='.5g',cmap='Greys',ax=a[0][0]);
a[0][0].set_title('Training Data')

plot_1 = sns.heatmap((metrics.confusion_matrix(y_test,ytest_predict)),annot=True,fmt='.5g',cmap='BuPu', ax=a[0][1]);
a[0][1].set_title('Test Data');


# In[117]:


print(classification_report(y_train, ytrain_predict))


# In[118]:


print(classification_report(y_test, ytest_predict))


# In[119]:


for index in range (1,14):
    sel=RFE(estimator= LR,  n_features_to_select = index)
    sel.fit(X_train, y_train)
    X_train_rfe= sel.transform(X_train)
    X_test_rfe= sel.transform(X_test)
    print('Selected Feature: ', index)
    run_LR(X_train_rfe, X_test_rfe, y_train, y_test)
    print()


# In[120]:


##Random Forest

model1 = RandomForestClassifier(n_estimators = 1000, random_state = 123)
model1.fit(X_train, y_train)


# In[121]:


ytrain_predict = model1.predict(X_train)
ytest_predict = model1.predict(X_test)


# In[122]:


model_score = model1.score(X_test, y_test)
print('Accuracy Score is ',model_score)


# In[123]:


model_score = model1.score(X_train, y_train)
print('Accuracy Score is ',model_score)


# In[124]:


confusion_matrix(y_train, ytrain_predict)


# In[125]:


f,a =  plt.subplots(1,2,sharex=True,sharey=True,squeeze=False)

plot_0 = sns.heatmap((metrics.confusion_matrix(y_train,ytrain_predict)),annot=True,fmt='.5g',cmap='Greys',ax=a[0][0]);
a[0][0].set_title('Training Data')

plot_1 = sns.heatmap((metrics.confusion_matrix(y_test,ytest_predict)),annot=True,fmt='.5g',cmap='BuPu', ax=a[0][1]);
a[0][1].set_title('Test Data');


# In[126]:


print(classification_report(y_train, ytrain_predict))


# In[127]:


print(classification_report(y_test, ytest_predict))


# In[128]:


param_grid = {
    'max_depth': [7, 10],
    'max_features': [4, 6],
    'min_samples_leaf': [50, 100, 300],
    'min_samples_split': [100, 150],
    'n_estimators': [301, 501]
}

rfcl = RandomForestClassifier()

grid_search = GridSearchCV(estimator = rfcl, param_grid = param_grid, cv = 3)


# In[129]:


grid_search.fit(X_train, y_train)


# In[130]:


grid_search.best_params_


# In[131]:


best_grid = grid_search.best_estimator_


# In[132]:


ytrain_predict = best_grid.predict(X_train)
ytest_predict = best_grid.predict(X_test)


# In[133]:


x=pd.DataFrame(best_grid.feature_importances_*100,index=X_train.columns).sort_values(by=0,ascending=False)
plt.figure(figsize=(12,7))
sns.barplot(x[0],x.index,palette='dark')
plt.xlabel('Feature Importance in %')
plt.ylabel('Features')
plt.title('Feature Importance using GB')
plt.show()


# In[134]:


confusion_matrix(y_train,ytrain_predict)


# In[135]:


f,a =  plt.subplots(1,2,sharex=True,sharey=True,squeeze=False)

plot_0 = sns.heatmap((metrics.confusion_matrix(y_train,ytrain_predict)),annot=True,fmt='.5g',cmap='Greys',ax=a[0][0]);
a[0][0].set_title('Training Data')

plot_1 = sns.heatmap((metrics.confusion_matrix(y_test,ytest_predict)),annot=True,fmt='.5g',cmap='BuPu', ax=a[0][1]);
a[0][1].set_title('Test Data');


# In[136]:


print(classification_report(y_train, ytrain_predict))


# In[137]:


print(classification_report(y_test, ytest_predict))


# In[138]:


print("Accuracy:",metrics.accuracy_score(y_test, ytest_predict))
print("Accuracy:",metrics.accuracy_score(y_train, ytrain_predict))


# In[139]:


from sklearn.model_selection import cross_val_score


# In[140]:


a = cross_val_score(best_grid, X_train, y_train, cv=2, scoring="accuracy")
a.mean()


# In[141]:


from statsmodels.stats.outliers_influence import variance_inflation_factor

def calc_vif(X):
    vif=pd.DataFrame()
    vif["variables"]=X.columns
    vif["VIF"] = [variance_inflation_factor(X.values,i) for i in range(X.shape[1])]
    
    return(vif)


# In[142]:


DF= calc_vif(X_train).sort_values(by='VIF', ascending = True)
DF


# In[143]:


from sklearn.neighbors import KNeighborsClassifier

KNN_model=KNeighborsClassifier()
KNN_model.fit(X_train, y_train)


# In[144]:


y_train_predict = KNN_model.predict(X_train)
y_test_predict = KNN_model.predict(X_test)


# In[145]:


f,a =  plt.subplots(1,2,sharex=True,sharey=True,squeeze=False)

plot_0 = sns.heatmap((metrics.confusion_matrix(y_train,y_train_predict)),annot=True,fmt='.5g',cmap='Greys',ax=a[0][0]);
a[0][0].set_title('Training Data')

plot_1 = sns.heatmap((metrics.confusion_matrix(y_test,y_test_predict)),annot=True,fmt='.5g',cmap='BuPu', ax=a[0][1]);
a[0][1].set_title('Test Data');


# In[146]:


print(classification_report(y_train, y_train_predict))


# In[147]:


print(classification_report(y_test, y_test_predict))


# In[148]:


print("Accuracy:",metrics.accuracy_score(y_test, y_test_predict))
print("Accuracy:",metrics.accuracy_score(y_train, y_train_predict))


# In[149]:


from sklearn.ensemble import AdaBoostClassifier

ADB_model = AdaBoostClassifier(n_estimators=100, random_state=1)
ADB_model.fit(X_train,y_train)


# In[150]:


y_train_predict = ADB_model.predict(X_train)
y_test_predict = ADB_model.predict(X_test)


# In[151]:


f,a =  plt.subplots(1,2,sharex=True,sharey=True,squeeze=False)

plot_0 = sns.heatmap((metrics.confusion_matrix(y_train,y_train_predict)),annot=True,fmt='.5g',cmap='Greys',ax=a[0][0]);
a[0][0].set_title('Training Data')

plot_1 = sns.heatmap((metrics.confusion_matrix(y_test,y_test_predict)),annot=True,fmt='.5g',cmap='BuPu', ax=a[0][1]);
a[0][1].set_title('Test Data');


# In[152]:


print(classification_report(y_train, y_train_predict))


# In[153]:


print(classification_report(y_test, y_test_predict))


# In[154]:


print("Accuracy:",metrics.accuracy_score(y_test, y_test_predict))
print("Accuracy:",metrics.accuracy_score(y_train, y_train_predict))


# In[155]:


from sklearn.ensemble import GradientBoostingClassifier
gbc1 = GradientBoostingClassifier(random_state=1)
gbc1=gbc1.fit(X_train,y_train)


# In[156]:


y_train_predict = gbc1.predict(X_train)
y_test_predict = gbc1.predict(X_test)


# In[157]:


f,a =  plt.subplots(1,2,sharex=True,sharey=True,squeeze=False)

plot_0 = sns.heatmap((metrics.confusion_matrix(y_train,y_train_predict)),annot=True,fmt='.5g',cmap='Greys',ax=a[0][0]);
a[0][0].set_title('Training Data')

plot_1 = sns.heatmap((metrics.confusion_matrix(y_test,y_test_predict)),annot=True,fmt='.5g',cmap='BuPu', ax=a[0][1]);
a[0][1].set_title('Test Data');


# In[158]:


print(classification_report(y_train, y_train_predict))


# In[159]:


print(classification_report(y_test, y_test_predict))


# In[160]:


print("Accuracy:",metrics.accuracy_score(y_test, y_test_predict))
print("Accuracy:",metrics.accuracy_score(y_train, y_train_predict))


# In[161]:


x=pd.DataFrame(gbc1.feature_importances_*100,index=X_train.columns).sort_values(by=0,ascending=False)
plt.figure(figsize=(12,7))
sns.barplot(x[0],x.index,palette='dark')
plt.xlabel('Feature Importance in %')
plt.ylabel('Features')
plt.title('Feature Importance using GB')
plt.show()


# In[162]:


X_train = X_train[["AGE","ApptIncomeVerifiedFlag","Description","EMPLOYCURRSTATUS", "LIMITLOANREQUESTED", "Policy_Decision_fs","Product","PERMANENTRESIDENT", "reason", "UMI"]] 
X_test = X_test[["AGE","ApptIncomeVerifiedFlag","Description","EMPLOYCURRSTATUS", "LIMITLOANREQUESTED", "Policy_Decision_fs","Product","PERMANENTRESIDENT", "reason", "UMI"]]


# In[163]:


print(classification_report(y_train, y_train_predict))


# In[164]:


print(classification_report(y_test, y_test_predict))


# In[165]:


a = cross_val_score(gbc2, X_train, y_train, cv=3, scoring="accuracy")
a.mean()


# In[ ]:


a= gbc2.predict(X_train)
gbc2.predict(X_test)


# In[ ]:


acc = accuracy_score(y_train,a)
print(acc)


# In[ ]:


import pickle


# In[ ]:


with open ('model_pickle','wb') as file:
    pickle.dump(gbc2,file)
    
with open('model_pickle','rb') as file:
    loaded_model = pickle.load(file)

loaded_model.predict(X_test)


# In[ ]:


X.head()


# In[169]:


gbc = GradientBoostingClassifier(random_state=1)
gbc.fit(X, y)


# In[170]:


y_predict = gbc.predict(X)


# In[171]:


print("Accuracy:",metrics.accuracy_score(y, y_predict))


# In[172]:


y_predict = gbc.predict(X)
print("Accuracy:",metrics.accuracy_score(y, y_predict))


# In[173]:


pred_gbc=gbc.predict(X.values)
pred_prob_gbc= gbc.predict_proba(X.values)

pred_gbc


# In[174]:


#probabilities

pred_prob_gbc


# In[175]:


#function to select second column for probabilities
def column(matrix,i):
    return[row[i] for row in matrix]
column(pred_prob_gbc,0)


# In[176]:


#Joining the raw data with the predictiona

output = credit_df1.copy()
output['Predictions- Approve or not']= pred_gbc
output['Predictions - Probability of approved']=column(pred_prob_gbc,0)
output['Predictions - Probability of cancel']=column(pred_prob_gbc,1)
output['Predictions - Probability of decline']=column(pred_prob_gbc,2)
output['Predictions- Approved or not des'] = 'Empty'
output['Predictions- Approved or not des'][output['Predictions- Approve or not']== 0] ="Approve"
output['Predictions- Approved or not des'][output['Predictions- Approve or not']== 1] ="Cancel"
output['Predictions- Approved or not des'][output['Predictions- Approve or not']== 2] ="Decline"
output.head(20)


# In[ ]:


output.to_excel('Prediction Output.xlsx', index=False)
output.to_excel('Prediction Output.xlsx', index=False)

os.getcwd()


# In[ ]:


clf = LogisticRegression(random_state=0).fit(X, y)

print(clf.coef_)


# In[ ]:


for idx, col_name in enumerate(X.columns):
    print("The coefficient for {} is {}".format(col_name, clf.coef_[0][idx]))

